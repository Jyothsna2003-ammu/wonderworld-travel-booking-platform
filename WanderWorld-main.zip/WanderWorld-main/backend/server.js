const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.resolve(__dirname, 'wanderworld.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('DB open error:', err.message);
  } else {
    console.log('Connected to DB');
    db.serialize(() => {
      db.run(`CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        city TEXT
        -- add other columns as needed
      )`, (err) => {
        if (err) console.error('Create table error:', err.message);
        else console.log('Locations table ready');
      });
    });
  }
});
