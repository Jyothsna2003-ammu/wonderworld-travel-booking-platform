import nav from 'header-data.js'

const nav = document.createElement('div')

const navbar = () => {
    console.log('connected')
}

export default navbar